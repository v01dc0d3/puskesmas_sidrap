<div class="modal-body">
    <div class="mb-3">
        <label for="nama_pasien">Nama Pasien</label>
        <input type="text" class="form-control" id="nama_pasien" disabled>
    </div>

    <div class="mb-3">
        <label for="tgl">Tanggal</label>
        <input type="text" class="form-control" id="tgl" disabled>
    </div>

    <div class="mb-3">
        <label for="resep">Resep Obat</label>
        <textarea class="form-control" placeholder="Masukkan Resep" id="resep"></textarea>
    </div>
</div>
<div class="modal-footer">
    <button type="button" id="tombol_ajukan_obat" class="btn btn-success">Ajukan</button>
</div>