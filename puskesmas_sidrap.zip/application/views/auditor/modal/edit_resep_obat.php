<div class="modal-body">
    <div class="mb-3">
        <label for="nama_pasien">Nama Pasien</label>
        <input type="text" class="form-control" id="nama_pasien" disabled>
    </div>

    <div class="mb-3">
        <label for="tgl">Tanggal</label>
        <input type="text" class="form-control" id="tgl" disabled>
    </div>

    <div class="mb-3">
        <label for="resep">Resep Obat</label>
        <textarea class="form-control" placeholder="Masukkan Resep" id="resep" disabled></textarea>
    </div>

    <div class="mb-3">
        <label for="status" class="form-label">Status</label>
        <select class="form-select" aria-label="status" id="status" disabled>
            <option selected disabled value=""></option>
            <option value="request">Meminta</option>
            <option value="selesai">Selesai</option>
        </select>
    </div>

</div>