<div class="modal-body">
    <div class="mb-3">
        <label for="pilih_halaman" class="form-label">Pilih Halaman</label>
        <select class="form-select" aria-label="pilih_halaman" id="pilih_halaman"></select>
    </div>

    <div class="mb-3">
        <label for="pilih_role" class="form-label">Pilih Role</label>
        <select class="form-select" aria-label="pilih_role" id="pilih_role"></select>
    </div>

</div>
<div class="modal-footer">
    <button type="button" id="tombol_tambah_akses_halaman" class="btn btn-success">Tambah</button>
</div>