<div class="modal-body">
    <div class="mb-3">
        <label for="full_name" class="form-label">Nama Pengguna</label>
        <input class="form-control" type="text" name="full_name" id="full_name">
    </div>

    <div class="mb-3">
        <label for="pilih_ruang" class="form-label">No Hp</label>
        <input class="form-control" type="text" name="no_hp" id="no_hp">
    </div>
</div>
<div class="modal-footer">
    <button type="button" id="tombol_edit_profil" class="btn btn-success">Simpan</button>
</div>