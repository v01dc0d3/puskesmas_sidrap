<div class="modal-body">
    <div class="mb-3">
        <label for="pilih_pasien" class="form-label">Nama Pasien</label>
        <select class="form-select" aria-label="pilih_pasien" id="pilih_pasien" disabled></select>
    </div>

    <div class="mb-3">
        <label for="pilih_ruang" class="form-label">Nama Ruang</label>
        <select class="form-select" aria-label="pilih_ruang" id="pilih_ruang" disabled></select>
    </div>

    <div class="mb-3">
        <label for="kajian">Kajian Paramedis (Data Fokus)</label>
        <textarea class="form-control" placeholder="Leave a comment here" id="kajian" style="height: 300px" disabled></textarea>
    </div>
</div>